public class CharacterController : MonoBehaviour
{
    public float walkSpeed = 5.0f;
    public float runSpeed = 10.0f;
    private float currentSpeed;

    private void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");

        // Calculate the movement direction.
        Vector3 moveDirection = new Vector3(horizontalInput, 0, verticalInput).normalized;

        // Determine the current speed based on player input.
        if (Input.GetKey(KeyCode.LeftShift))
        {
            currentSpeed = runSpeed;
        }
        else
        {
            currentSpeed = walkSpeed;
        }

        // Apply movement.
        transform.Translate(moveDirection * currentSpeed * Time.deltaTime);
    }
}

public class CharacterController : MonoBehaviour
{
    // ...

    private bool isSneaking = false;

    private void Update()
    {
        // ...

        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            isSneaking = true;
        }

        if (Input.GetKeyUp(KeyCode.LeftControl))
        {
            isSneaking = false;
        }

        // Adjust the movement speed when sneaking.
        if (isSneaking)
        {
            currentSpeed = walkSpeed * 0.5f; // Adjust the speed as needed.
        }
        else
        {
            // Restore normal speed.
            if (Input.GetKey(KeyCode.LeftShift))
            {
                currentSpeed = runSpeed;
            }
            else
            {
                currentSpeed = walkSpeed;
            }
        }
    }
}
